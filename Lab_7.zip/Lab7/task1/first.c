#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <wait.h>
#include <sys/types.h>
int fatal (char *s){
perror (s) ;
exit(1);
}
int conv(char *com1[], char *com2[]){
int p[2], status;
switch(fork()){
case -1:
fatal("Ошибка первого вызова fork!");
case 0:
break;
default:
wait(&status);
return(status);
}

if (pipe (p) == -1)
fatal("Ошибка вызова pipe!");
switch(fork()){
case -1:
fatal("Ошибка второго вызова fork!");
case 0:
dup2(p[1],1);
close(p[0]);
close(p[1]);
execvp(com1[0], com1);
fatal("Ошибка первого вызова execvp!");
default:
dup2(p[0], 0);
close (p[0]);
close (p[1]);
execvp(com2[0], com2);
fatal("Ошибка второго вызова execvp!");
}
}

int main(){
char *one[2] = {"who", NULL};
char *two[2] = {"sort", NULL};
int ret;
ret = conv(one, two);
exit(0) ;
}
