#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#define FIFO_NAME "myfifo"
#define BUF_SIZE  512
int main (void){
FILE * fifo;
char * buf;
if (mkfifo ("myfifo", 0640) == -1) {if (errno != EEXIST)
fprintf (stderr, "Cannot create fifo\n");
return 1;
}
fifo = fopen (FIFO_NAME, "r");
if (fifo == NULL) {
fprintf (stderr, "Cannot open fifo\n");
return 1;
}
buf = (char *) malloc (BUF_SIZE);
if (buf == NULL) {
fprintf (stderr, "malloc () error\n");
return 1;
}
fscanf (fifo, "%s", buf);
fclose (fifo);

int c;
for(int i=0;i<strlen(buf);i++){
    c=buf[i];
    buf[i]=toupper(c);
}
int fif;
fif = open (FIFO_NAME, O_WRONLY);
if (fif == -1) {
fprintf (stderr, "Cannot open fifo\n");
return 1;
}
if (write (fif, buf, strlen (buf)) == -1) {
fprintf (stderr, "write() error\n");
return 1;
}
close (fif);
free (buf);
unlink (FIFO_NAME);
return 0;
}
