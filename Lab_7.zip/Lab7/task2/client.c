#include<stdio.h>
#include<fcntl.h>
#include<string.h>
#include<stdlib.h>
#include <stddef.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

#define FIFO_NAME "myfifo"
#define BUF_SIZE  512

int main (int argc, char ** argv){
int fifo;
if (argc < 2) {
fprintf (stderr, "Too few arguments\n");
return 1;
}
fifo = open (FIFO_NAME, O_WRONLY);
if (fifo == -1) {
fprintf (stderr, "Cannot open fifo\n");
return 1;
}
for(int i=1;i<argc;i++){
if (write (fifo, argv[i], strlen (argv[i])) == -1) {
fprintf (stderr, "write() error\n");
return 1;
}
}
close (fifo);

FILE * fif;
char * buf;
fif = fopen (FIFO_NAME, "r");
if (fif == NULL) {
fprintf (stderr, "Cannot open fifo\n");
return 1;
}
buf = (char *) malloc (BUF_SIZE);
if (buf == NULL) {
fprintf (stderr, "malloc () error\n");
return 1;
}

fscanf (fif, "%s", buf);
printf ("%s\n", buf);
fclose (fif);
free (buf);
unlink (FIFO_NAME);
return 0;
}
