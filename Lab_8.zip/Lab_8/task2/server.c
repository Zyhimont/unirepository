#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <errno.h>
#define QKEY (key_t)0105
#define QPERM 0660 
#define MAXOBN 50
#define MAXPRIOR 10

struct q_entry{
long mtype;
char mtext[MAXOBN+1];
};

int proc_obj (struct q_entry *msg){
printf (" %s",msg->mtext);
}

int init_queue(void){
int queue_id;
if((queue_id = msgget(QKEY, IPC_CREAT | QPERM)) == -1)
perror("Ошибка вызова msgget");
return (queue_id);
}

int warn(char *s){
fprintf(stderr, "Предупреждение: %s\n", s);
}

int server(void){
int mien, r_qid;
struct q_entry r_entry;
if((r_qid = init_queue()) == -1)
return (-1);
for (; ; ){
if((mien = msgrcv(r_qid, &r_entry, MAXOBN, (-1 * MAXPRIOR), MSG_NOERROR)) == -1){
perror("Ошибка вызова msgrcv");
return (-1);
}
else{
r_entry.mtext[mien]='\0';
proc_obj(&r_entry);
}
}
}

int main(){
pid_t pid;
switch(pid = fork()){
case 0:
server();
break;
case -1:
warn("Не удалось запустить сервер");
break;
default:
printf("Серверный процесс с идентификатором %d\n", pid);
}
exit(pid != -1 ? 0 : 1);
}
