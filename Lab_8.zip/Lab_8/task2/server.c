#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <errno.h>
#define QKEY (key_t)0105
#define QPERM 0660
#define MAXOBN 50
#define MAXPRIOR 10

struct q_entry{
long mtype;
char mtext[MAXOBN+1];
};

int init_queue(void){
int queue_id;
if((queue_id = msgget(QKEY, IPC_CREAT | QPERM)) == -1)
perror("Ошибка вызова msgget");
return (queue_id);
}

int warn(char *s){
fprintf(stderr, "Предупреждение: %s\n", s);
}

int enter(char *objname){
int len, s_qid;
struct q_entry s_entry; 
if ((len = strlen(objname)) > MAXOBN){
warn("Слишком длинное имя!");
return (-1);
}
if((s_qid = init_queue()) == -1)
return (-1);
s_entry.mtype = 2.0;
strncpy(s_entry.mtext, objname, MAXOBN);
if(msgsnd(s_qid, &s_entry, len, IPC_NOWAIT) == -1){
perror("Ошибка вызова msgsnd");
return (-1);
}
else
return (0);
}

int main(int argc, char **argv){
if(argc < 2 ){
fprintf(stderr, "наберите сообщение \n", argv[0]);
exit (1);
}
for(int i=1;i<argc;i++){
if(enter(argv[i]) < 0){
warn("Ошибка в процедуре enter");
exit (3);
exit(0) ;
}
}
}
