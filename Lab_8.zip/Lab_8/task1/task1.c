#include <stdio.h>
#include <string.h>
#include <sys/shm.h>
#include <stdlib.h>
#define SIZE 4096

int main (void) {
int ind;
char * ptr;
int shm_size;
struct shmid_ds ds;
ind = shmget (IPC_PRIVATE, SIZE, IPC_CREAT | IPC_EXCL | 0600);
if (ind == -1) {
fprintf (stderr, "shmget error\n");
return 1;
}
ptr = (char *) shmat (ind, NULL, 0);
if (ptr == (char *) -1) {
fprintf (stderr, "shmat error\n");
return 1;
}
shmctl (ind, IPC_STAT, &ds);
system("ipcs -m");
printf ("ID: %d\n", ind);
printf ("Press Enter to delete object");
fgetc (stdin);
shmdt (ptr);
shmctl (ind, IPC_RMID, NULL);
system("ipcs -m");
return 0;
}
