#include <stdlib.h>
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
int honey=0;
int N;
int H;

pthread_cond_t count1;
pthread_cond_t count2;
pthread_mutex_t mutex;
void * put (void *argic){
int num=*(int *)argic;
while(1){
sleep(random()%5);
pthread_mutex_lock(&mutex);
while(honey==H)
pthread_cond_wait(&count2,&mutex);
honey++;
printf("%s","пчела ");
printf("%d",num); 
printf("%s"," принесла глоток меда, всего в горшке глотков:");
printf("%d",honey);
printf("%s","\n");
if(honey==H){
pthread_cond_signal(&count1);
printf("%s","эта пчела будит медведя\n");
}
pthread_mutex_unlock(&mutex);
}
}

void * eat(void *arg){    
for(;;){
  pthread_mutex_lock(&mutex);
  while(honey!=H)
  pthread_cond_wait(&count1,&mutex);
  printf("%s","медведь проснулся\n");  
  sleep(2);
  honey=0;
  printf("%s","медведь съел весь мед и заснул\n");
  pthread_cond_broadcast(&count2);  
  pthread_mutex_unlock(&mutex);
      }
    }

int main(int argc,char **argv){
printf("%s","введите количество пчел ");
scanf("%d",&N);
printf("%s","введите кол-во глотков меда в горшке ");
scanf("%d",&H);
pthread_t bee[N];
pthread_t bear;
int number[N];
for(int i=0;i<N;i++){number[i]=i+1;}
pthread_cond_init(&count1,NULL);
pthread_cond_init(&count2,NULL);    
pthread_mutex_init(&mutex,NULL);
pthread_create(&bear,NULL,&eat,NULL);
for(int i=0;i<N;i++){
  pthread_create(&bee[i],NULL,&put,&number[i]);   
  };
fgetc(stdin);
for(int i=0;i<N;i++){
  pthread_join(bee[i],NULL);
  };
pthread_cond_destroy(&count1);
pthread_cond_destroy(&count2);
pthread_mutex_destroy(&mutex);
return 0;
}      
