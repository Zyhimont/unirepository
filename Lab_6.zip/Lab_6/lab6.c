#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <dirent.h>

int fp;
int * t;
sigjmp_buf position;
int main()
{
static struct sigaction act;
static struct sigaction act1;

void catchint (int);

act.sa_handler = SIG_IGN;
act1.sa_handler =catchint;
sigfillset(&(act.sa_mask));
sigfillset(&(act1.sa_mask));

sigaction(SIGINT, &act, NULL);
sigaction(SIGSEGV, &act1, NULL);
*t=0;

while(1){};

return 0;
}
void catchint(int sig){if(fp==0){
    fp = creat("protocol.txt",S_IRWXU);}
   write(fp,"Segmentation violation\n",24);
    
}
